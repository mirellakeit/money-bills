import java.util.Scanner;

  
class Main {

 
  
  public static void main(String[] args) {
    Operacao operacao = new Operacao();
    Scanner scanner = new Scanner(System.in);
    int valor = Integer.parseInt(scanner.nextLine());
    scanner.close();
    operacao.quantidadeDeNotas(valor);
    }
  }
