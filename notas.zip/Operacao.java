class Operacao {

int[] notas = {100, 50, 20, 10, 5, 2, 1};
//se quiser notas diferentes, é só alterar aqui, tipo, sei lá, hoje em dia já tem nota de R$ 200 e não tem mais nota de 1 real.
  
 void quantidadeDeNotas(int valor) // a função ne
  
  {
    for(int i = 0; i < notas.length; i++)
    {
      int nota = notas[i]; //pra pegar o int em notas[i]
      
      int partesDoValor = (valor - (valor % nota) );
      //ex: centenas = (valor - valor%100), que é o valor original menos número que sobra na divisião por 100, sobrando só as centenas.
      
      int qtdDeNotas = (partesDoValor /nota);
      //ex: a quantidade de notas de 100 reais são as centenas do valor original dividido por 100.
      
      valor -= partesDoValor;
      //ex: tirando as centenas do valor original, pra sobrar só partes que são divisíveis por 50, ou por 20, etc.
      
      System.out.println(qtdDeNotas + " Notas de R$ " + nota + ",00" );
      //aí a parte que pede pra printar, bem espertinha
      
    }
   }
  
}